#include"reverse.h"

using namespace std;

Reverse::Reverse(char pcolor) {
	setCardColor(pcolor);
}