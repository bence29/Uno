/*s
rand(time(0));
    int t[100000];
    int n[21] = { 0 };
    for (int i = 0; i < 100000; i++) {
        t[i] = (rand() % 21) + 1;
        cout << t[i]<< endl;
        switch (t[i]) {
            case 1: n[0]++; break;
            case 2: n[1]++; break;
            case 3: n[2]++; break;
            case 4: n[3]++; break;
            case 5: n[4]++; break;
            case 6: n[5]++; break;
            case 7: n[6]++; break;
            case 8: n[7]++; break;
            case 9: n[8]++; break;
            case 10: n[9]++; break;
            case 11: n[10]++; break;
            case 12: n[11]++; break;
            case 13: n[12]++; break;
            case 14: n[13]++; break;
            case 15: n[14]++; break;
            case 16: n[15]++; break;
            case 17: n[16]++; break;
            case 18: n[17]++; break;
            case 19: n[18]++; break;
            case 20: n[19]++; break;
            case 21: n[20]++; break;
        }
    }
    cout << endl << endl << endl;
    for (int i = 0; i < 21; i++) {
        cout << n[i] << endl;
    }



    cout<<""
    srand(time(0));
    bool end=true;
    while (end) {
        bool c;
        unsigned i;
        c ? i++ : i--;
    }
*/