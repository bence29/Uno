#include"colorswitch.h"

using namespace std;