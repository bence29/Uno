#include"drawtwo.h"

using namespace std;

DrawTwo::DrawTwo(char pcolor) {
	setCardColor(pcolor);
}