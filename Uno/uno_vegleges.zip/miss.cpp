#include"miss.h"

using namespace std;

Miss::Miss(char pcolor) {
	setCardColor(pcolor);
}