#include"normal.h"

using namespace std;

Normal::Normal(char pcolor, unsigned pnumber) {
	setCardColor(pcolor);
	setCardNumber(pnumber);
}
